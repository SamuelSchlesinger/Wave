import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;
import javax.swing.JFrame;
import java.awt.Graphics2D;
import java.awt.geom.*;
import java.awt.Dimension;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class Animation extends JPanel implements ActionListener, MouseListener { 
    
    private Timer timer = new Timer(40, this);
    private Medium test = new Medium(900, 900);

    public Animation() {
        super(true);
        addMouseListener(this);
    }
 
    public void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        /* Rubric for animation */

        // Background 
        /*----------------------------*/
        g2d.setColor(Color.BLACK);
        Dimension d = getSize();
        int width = (int) d.getWidth();
        int height = (int) d.getHeight();
        g2d.fillRect(0,0,width,height);
        /*-----------------------------*/
        test.display(g2d);    
        timer.start(); 
    }

    // All time based things happen here
    public void actionPerformed(ActionEvent e) {        
        test.update();
        repaint();    
    }

    public void mouseClicked(MouseEvent e) {
        test.ripple(e.getY()/Medium.RESOLUTION, e.getX()/Medium.RESOLUTION);
    }

    public void mousePressed(MouseEvent e){}
    public void mouseReleased(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Hello world");
        Animation test = new Animation();
        frame.add(test);
        frame.setSize(900, 900);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
